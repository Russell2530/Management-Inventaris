@extends('layouts.app')

@section('title', 'Edit Produk')

@section('content')
<div class="max-w-3xl mx-auto bg-white shadow-lg rounded-2xl p-8 mt-10">
    <h2 class="text-3xl font-bold text-center text-gray-800 mb-6">Edit Produk</h2>

    <form action="{{ route('products.update', $product->id) }}" method="POST" enctype="multipart/form-data" class="space-y-6">
        @csrf
        @method('PUT')

        <!-- Nama Produk -->
        <div>
            <label class="block font-semibold text-gray-700">Nama Produk</label>
            <input type="text" name="nama_produk" value="{{ old('nama_produk', $product->nama_produk) }}"
                class="w-full border rounded-xl p-3 focus:ring focus:ring-blue-400">
            @error('nama_produk') <p class="text-red-500 text-sm">{{ $message }}</p> @enderror
        </div>

        <!-- Stok Produk -->
        <div>
            <label class="block font-semibold text-gray-700">Stok Produk</label>
            <input type="number" name="stok" value="{{ old('stok', $product->stok) }}"
                class="w-full border rounded-xl p-3 focus:ring focus:ring-blue-400">
            @error('stok') <p class="text-red-500 text-sm">{{ $message }}</p> @enderror
        </div>

        <!-- Kategori Produk -->
        <div>
            <label class="block font-semibold text-gray-700">Kategori</label>
            <input type="text" name="kategori" value="{{ old('kategori', $product->kategori) }}"
                class="w-full border rounded-xl p-3 focus:ring focus:ring-blue-400">
            @error('kategori') <p class="text-red-500 text-sm">{{ $message }}</p> @enderror
        </div>

        <!-- Gambar Produk -->
        <div>
            <label class="block font-semibold text-gray-700">Gambar Produk</label>
            <input type="file" name="gambar" id="gambarInput" class="w-full border rounded-xl p-3 bg-gray-50">

            @if($product->gambar)
                <div class="mt-4">
                    <p class="text-sm text-gray-500 mb-2">Gambar Lama:</p>
                    <img src="{{ asset('storage/'.$product->gambar) }}" class="w-40 h-40 object-cover rounded-xl border">
                </div>
            @endif

            <!-- Preview Baru -->
            <div class="mt-4">
                <p class="text-sm text-gray-500 mb-2">Preview Gambar Baru:</p>
                <img id="previewImage" class="w-40 h-40 object-cover rounded-xl border hidden">
            </div>
        </div>

        <!-- Tombol Submit -->
        <div class="text-center">
            <button type="submit" class="px-6 py-3 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-xl shadow-lg transition">
                Update Produk
            </button>
        </div>
    </form>
</div>

<!-- Script Preview Gambar -->
<script>
    document.getElementById('gambarInput').addEventListener('change', function(event) {
        const file = event.target.files[0];
        const preview = document.getElementById('previewImage');

        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                preview.src = e.target.result;
                preview.classList.remove('hidden');
            }
            reader.readAsDataURL(file);
        } else {
            preview.src = "";
            preview.classList.add('hidden');
        }
    });
</script>
@endsection
