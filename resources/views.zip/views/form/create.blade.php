@extends('layouts.app')

@section('title', 'Tambah Produk')

@section('content')
<div class="max-w-3xl mx-auto bg-white shadow-lg rounded-2xl p-8 mt-10">
    <h2 class="text-3xl font-bold text-center text-gray-800 mb-6">Form Peminjaman</h2>

    @if(session('success'))
        <div class="mb-4 p-3 bg-green-100 text-green-700 rounded-lg">
            {{ session('success') }}
        </div>
    @endif

    <form action="{{ route('form.store') }}" method="POST" enctype="multipart/form-data" class="space-y-6">
        @csrf

        <!-- Nama Produk -->
        <div>
            <label class="block font-semibold text-gray-700">Nama Barang</label>
            <input type="text" name="nama_produk" class="w-full border rounded-xl p-3 focus:ring focus:ring-blue-400" placeholder="Masukkan nama produk">
            @error('nama_produk') <p class="text-red-500 text-sm">{{ $message }}</p> @enderror
        </div>

        <!-- Stok Produk -->
        <div>
            <label class="block font-semibold text-gray-700">Nama Peminjam</label>
            <input type="text" name="nama_peminjam" class="w-full border rounded-xl p-3 focus:ring focus:ring-blue-400" placeholder="Masukkan nama peminjam">
            @error('nama_peminjam') <p class="text-red-500 text-sm">{{ $message }}</p> @enderror
        </div>

        <!-- Kategori Produk -->
        <div>
            <label class="block font-semibold text-gray-700">Tanggal Pinjam</label>
            <input type="date" name="tanggal_pinjam" class="w-full border rounded-xl p-3 focus:ring focus:ring-blue-400" placeholder="Masukkan tanggal pinjam">
            @error('tanggal_pinjam') <p class="text-red-500 text-sm">{{ $message }}</p> @enderror
        </div>

        <!-- Gambar Produk + Preview -->
        <div>
            <label class="block font-semibold text-gray-700">Tanggal Kembali</label>
            <input type="date" name="tanggal_kembali" class="w-full border rounded-xl p-3 focus:ring focus:ring-blue-400" placeholder="Masukkan tanggal kembali">
            @error('tanggal_kembali') <p class="text-red-500 text-sm">{{ $message }}</p> @enderror
        </div>

        <!-- Tombol Submit -->
        <div class="text-center">
            <button type="submit" class="px-20 py-3 bg-blue-600 text-white font-semibold rounded-xl shadow-lg hover:bg-blue-700 transition">
                Submit
            </button>
        </div>
    </form>
</div>

@endsection
