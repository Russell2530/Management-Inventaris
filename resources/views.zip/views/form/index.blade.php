@extends('layouts.app')

@section('title', 'Daftar Peminjam')

@section('content')
<div class="max-w-6xl mx-auto mt-10">
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-3xl text-white font-bold">Daftar Peminjam</h1>
    </div>

    <table class="w-full border-collapse bg-white shadow rounded-xl overflow-hidden">
        <thead class="bg-gray-100">
            <tr>
                <th class="p-3 text-left">#</th>
                <th class="p-3 text-left">Nama Produk</th>
                <th class="p-3 text-left">Nama Peminjam</th>
                <th class="p-3 text-left">Tanggal Peminjam</th>
                <th class="p-3 text-left">Tanggal Kembali</th>
                <th class="p-3 text-center">Aksi</th>
            </tr>
        </thead>
        <tbody>
            @forelse($form as $forms)
            <tr class="border-t">
                <td class="p-3">{{ $loop->iteration }}</td>
                <td class="p-3">{{ $forms->nama_produk }}</td>
                <td class="p-3">{{ $forms->nama_peminjam }}</td>
                <td class="p-3">{{ $forms->tanggal_pinjam }}</td>
                <td class="p-3">{{ $forms->tanggal_kembali }}</td>
                </td>
                <td class="p-3 text-center flex gap-2 justify-center">
                    <a href="{{ route('products.edit', $forms->id) }}" class="text-black rounded-lg ">Approve</a>
                    <form action="{{ route('products.destroy', $forms->id) }}" method="POST" onsubmit="return confirm('Yakin mau hapus?')">
                        @csrf
                        @method('DELETE')
                        <button class="text-black rounded-lg ">Decline</button>
                    </form>
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="6" class="text-center p-4 text-gray-500">Belum ada produk</td>
            </tr>
            @endforelse
        </tbody>
    </table>

    <div class="mt-6">
        {{ $form->links() }}
    </div>
</div>
@endsection
